clear all
clc
close all


addpath('/Users/zhesoffice/Documents/���д�/���ݿ�');

load randomprojection_AR
DATA = DATA./ repmat(sqrt(sum(DATA .* DATA)), [size(DATA, 1) 1]); %normalize
c = length(unique(Label));
numClass = zeros(c,1);
for i = 1 : c
    numClass(i, 1) = length(find(Label == i));
end

train_num = 10;
K = c * 5;
for ii = 1 : 10
train_data = []; test_data = []; 
train_label = []; test_label = [];
for i = 1 : c
    index = find(Label == i); 
    randindex = index(randperm(length(index)));
    train_data = [train_data DATA(:,randindex(1 : train_num))];
    train_label = [train_label  Label(randindex(1 : train_num))];
  
    test_data = [test_data DATA(:, randindex(train_num + 1 : end))];
    test_label = [test_label  Label(randindex(train_num + 1 : end))];
    train_index(i, :) = find(train_label == i);
end
for i = 1 : size(train_data, 2)
    a = train_label(i);
    Htr(a, i) = 1;
end 
for i = 1 : (size(test_data, 2))
    a = test_label(i);
    Htt(a, i) = 1;
end

H_D = []; D_label = [];
for i = 1 : c
    H_D = blkdiag(H_D, ones(1, K / c));
end

Dinit = initializationDictionary(train_data, Htr, K, 10, 30); %��ʼ��D

alpha = 100;
beta = 10;
lambda = 1;
tic
[D1, P1, A1, value1] = New_DPL(train_data, Dinit, Htr, H_D, K, c, alpha, beta, lambda);
[D2, P2, A2, value2] = New_DPL_fixD(train_data, Dinit, Htr, H_D, K, c, alpha, beta, lambda);
train_time(ii) = toc;
%% classfication 1 knn linear classifier

T_train1 = H_D * P1' * train_data;
T_test1 = H_D * P1' * test_data; 
T_train1 = T_train1./ repmat(sqrt(sum(T_train1 .* T_train1)), [size(T_train1, 1) 1]);
T_test1 = T_test1./ repmat(sqrt(sum(T_test1 .* T_test1)), [size(T_test1, 1) 1]);
mdl = fitcknn(T_train1', train_label);
class_test1 = predict(mdl, T_test1');
accuracy1(ii) = sum(test_label' == class_test1)/length(test_label);

T_train2 = H_D * P2' * train_data;
T_test2 = H_D * P2' * test_data; 
T_train2 = T_train2./ repmat(sqrt(sum(T_train2 .* T_train2)), [size(T_train2, 1) 1]);
T_test2 = T_test2./ repmat(sqrt(sum(T_test2 .* T_test2)), [size(T_test2, 1) 1]);
mdl = fitcknn(T_train2', train_label);
class_test2 = predict(mdl, T_test2');
accuracy2(ii) = sum(test_label' == class_test2)/length(test_label);



fprintf('ii = %d; ', ii);
fprintf('Recognition rate for our DPL1 is: %.03f; ', accuracy1(ii));
fprintf('Max accuracy = %.03f;\n', max(accuracy1));
fprintf('Recognition rate for our DPL2 is: %.03f; ', accuracy2(ii));
fprintf('Max accuracy = %.03f;\n', max(accuracy2));
end






mean(accuracy2)
std(accuracy2)
mean(train_time)
mean(test_time)

imagesc(ans)
colormap(gray(256))
plot(value)

