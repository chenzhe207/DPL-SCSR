function [D, P, A, value] = DPL_SLRR(X, D, H, H_D, K, c, alpha, beta, lambda) 


maxIter = 20;
[d, n] = size(X);
k = K / c;

%% initialize
P = zeros(d, K);
Q = []; 
for i = 1 : c
    Q = blkdiag(Q, ones(k, n / c));
end
%% starting iterations
iter = 0;
while iter < maxIter
    iter = iter + 1;
       
    %update A
    
    A = inv((alpha + beta) * eye(K) + D' * D) * ((alpha * P' + D') * X + beta * Q);
    A = max(A, 0);
    
    
    
    %update D
    [D, ~] = UpdateD_us(X, A, D);
%     D = normcol_lessequal(X * A' * inv(A * A' + 1e-4 * eye(K)));
    
    %update P  
    v  = sqrt(sum(P .* P, 2) + eps);
    V  = diag(1 ./ (v));
    P =  inv(X * X' + alpha \ lambda * V) * X * A';
        
      
%     %update S
%     S = (mu * H_D * A - Y2) * inv(beta * L + mu * eye(n));

    
       
%    %% convergence check   
%    leq1 = A - P' * X;
%    leq2 = S - H_D * A;
% 
%    stopC = max(max(max(abs(leq1))), max(max(abs(leq2))));
%    if stopC < tol || iter >= maxIter    
%        break;
%    else
%        Y1 = Y1 + mu * leq1;
%        Y2 = Y2 + mu * leq2;
%        mu = min(max_mu, mu * rho);
%    end
% % %    if (iter==1 || mod(iter, 5 )==0 || stopC<tol)
% % %            disp(['iter ' num2str(iter) ',mu=' num2str(mu,'%2.1e') ...
% % %            ',stopALM=' num2str(stopC,'%2.3e') ]);
% % %    end  
% % 
%     

  
%  
%     value1 = norm(X - D * A, 'fro') ^ 2;
%     value2 = norm(A - P' * X, 'fro') ^ 2;
%     value3 = norm(H - H_D * A, 'fro') ^ 2;
%     value4 = sum(sqrt(sum(P .* P, 2)));
%     value(iter) =  value1 + alpha * value2 + beta * value3 + lambda * value4;
%    

end
value = 0;
end


