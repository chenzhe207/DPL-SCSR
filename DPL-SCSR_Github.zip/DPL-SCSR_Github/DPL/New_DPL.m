function [D, P, A, value] = New_DPL(X, D, H, H_D, K, c, alpha, beta, lambda) 


maxIter = 20;
[d, n] = size(X);
k = K / c;

%% initialize
P = zeros(d, K);
%% starting iterations
iter = 0;
while iter < maxIter
    iter = iter + 1;
       
    %update A
    
    A = inv(alpha * eye(K) + D' * D + beta * H_D' * H_D) * ((alpha * P' + D') * X + H_D' * beta * H);
    A = max(A, 0);
        
    %update D
    [D, ~] = UpdateD_us(X, A, D);
    
    %update P  
    v  = sqrt(sum(P .* P, 2) + eps);
    V  = diag(1 ./ (v));
    P =  inv(X * X' + alpha \ lambda * V) * X * A';
    
%     v  = sum(P .* P, 2) + eps;
%     V  = diag(0.5 * v .^ (2\(0.5-2)));
%     P =  inv(X * X' + alpha \ lambda * V) * X * A';
%         
      

end
%     value1 = norm(X - D * A, 'fro') ^ 2;
%     value2 = norm(A - P' * X, 'fro') ^ 2;
%     value3 = norm(H - H_D * A, 'fro') ^ 2;
%     value4 = sum(sqrt(sum(P .* P, 2)));
%     value =  2 \ (value1 + alpha * value2 + beta * value3 + lambda * value4);
value = 0;
end


