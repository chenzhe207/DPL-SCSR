

function accuracy = classification(W, Hlabel,Gamma, K, c)

k = K / c;
% classify process
errnum = 0;
err = [];
prediction = [];
for featureid=1:size(Gamma,2)
    spcode = Gamma(:,featureid);
    [score_est, index] =  sort(W * spcode, 'descend');
    index_new = ceil(index(1 : k) ./ k);
    table = unique(index_new);
    hTable = histc(index_new, table);
    [maxCount, idx] = max(hTable);
    
    score_gt = Hlabel(:,featureid);
    [maxv_gt, maxind_gt] = max(score_gt);
    
    if(table(idx)~=maxind_gt)
        errnum = errnum + 1;      
    end
    clear table score_est idx index
end
accuracy = (size(Gamma,2)-errnum)/size(Gamma,2);