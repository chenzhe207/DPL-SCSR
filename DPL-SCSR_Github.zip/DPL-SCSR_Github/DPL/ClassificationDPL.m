function [PredictLabel Error] = ClassificationDPL( test_data, D , c, P, K )

%Projective representation coefficients estimation
PredictCoef = P'*test_data;
k = K / c; 
% Class-specific reconstruction error caculation
for i = 1 : c
    Error(i,:)= sum((D(:, (i-1)*k+1:i*k)*PredictCoef((i-1)*k+1:i*k,:)-test_data).^2);
end
[Distance PredictLabel] = min(Error);



